<?php

// -----------------------------------------
// semplice
// admin/atts/modules/blogcomments.php
// -----------------------------------------

$blogcomments = $atts->get('blogcomments', array('handler' => 'editor-listen'));

?>