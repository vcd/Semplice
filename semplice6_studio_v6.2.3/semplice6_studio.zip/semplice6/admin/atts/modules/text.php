<?php

// -----------------------------------------
// semplice
// admin/atts/modules/text.php
// -----------------------------------------

$text = array(
	'options' => array(
		'title'  	 => 'Options',
		'hide-title' => true,
		'break'		 => '4',
		//'data-hide-mobile' => true,
		'edit_paragraph' => array(
			'data-input-type' 	=> 'button',
			'title'		 		=> 'Edit',
			'button-title'		=> 'Edit Paragraph',
			'size'		 		=> 'span4',
			'class'				=> 'semplice-button init-wysiwyg-ep',
			'responsive'   => true,
		),
	),
);

?>