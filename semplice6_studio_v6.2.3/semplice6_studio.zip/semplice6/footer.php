<?php

// -----------------------------------------
// semplice
// footer.php
// -----------------------------------------
	
	// photoswipe
	get_template_part('partials/photoswipe', 'standard');
	// back to top arrow
	semplice_back_to_top_arrow();
	// custom cursor
	semplice_custom_cursor('output');
	// footer
	wp_footer();
	
?>
	</body>
</html>