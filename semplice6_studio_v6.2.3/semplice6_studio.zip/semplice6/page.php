<?php

// -----------------------------------------
// semplice
// index.php
// -----------------------------------------

// include header
get_header();

// show content
semplice_show_content(semplice_get_id(), 'page');

// include footer
get_footer();

?>