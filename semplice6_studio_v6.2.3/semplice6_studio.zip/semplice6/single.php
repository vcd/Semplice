<?php

// -----------------------------------------
// semplice
// single.php
// -----------------------------------------

// include header
get_header();

// show content
semplice_show_content(semplice_get_id(), 'post');

// include footer
get_footer();

?>