<?php

// -----------------------------------------
// semplice
// archive.php
// -----------------------------------------

// include header
get_header();

// show content
semplice_show_content(semplice_get_id(), 'taxonomy');

// include footer
get_footer();

?>