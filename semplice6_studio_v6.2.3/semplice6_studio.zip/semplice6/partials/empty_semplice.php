<?php

// -----------------------------------------
// semplice
// partials/empty_semplice.php
// -----------------------------------------

?>

<div class="no-content">
	Empty content<br /><span>It appears that you have a totally empty page. Please visit our editor and add some content to your page.</span>
</div>