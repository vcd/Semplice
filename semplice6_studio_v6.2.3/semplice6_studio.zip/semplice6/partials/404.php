<?php

// -----------------------------------------
// semplice
// partials/404.php
// -----------------------------------------

?>


<div class="no-content">
	404 - Not found<br /><span>This page could not be found.<br />Continue to the <a href="<?php echo home_url(); ?>">Homepage</a></span>
	</div>