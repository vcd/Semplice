<?php

// -----------------------------------------
// semplice
// partials/no_posts.php
// -----------------------------------------

?>

<div class="no-content">
	No posts<br /><span>You have no posts in your blog. Start adding some posts in your dashboard.</span>
</div>