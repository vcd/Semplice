<?php

// -----------------------------------------
// semplice
// partials/empty_content.php
// -----------------------------------------

?>

<div class="no-content">
	Empty content<br /><span>Before getting a preview of your page or project please add<br /> some content in our editor, save it and hit preview again.</span>
</div>